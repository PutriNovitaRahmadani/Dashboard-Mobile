import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Content box at the bottom
          Positioned(
            bottom: 0,
            right: 0,
            left: 0,
            child: Container(
              height: MediaQuery.of(context).size.height / 2.40,
              decoration: BoxDecoration(
                color: Colors.grey,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(40),
                  topRight: const Radius.circular(40),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Informasi Keuangan',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),

                    // Box 1 - Informasi Pendapatan dan Pengeluaran
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            color: Colors.white,
                            child: Column(
                              children: [
                                Text(
                                  'Pendapatan',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                // Tambahkan widget untuk menampilkan data pendapatan
                                // dari halaman lain
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            color: Colors.white,
                            child: Column(
                              children: [
                                Text(
                                  'Pengeluaran',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                // Tambahkan widget untuk menampilkan data pengeluaran
                                // dari halaman lain
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                      height: 20,
                    ),

                    // Box 2 - Laba Rugi dan Total Transaksi
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            color: Colors.white,
                            child: Column(
                              children: [
                                Text(
                                  'Laba Rugi',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                // Tambahkan widget untuk menampilkan data laba rugi
                                // dari halaman lain
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            color: Colors.white,
                            child: Column(
                              children: [
                                Text(
                                  'Total Transaksi',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                // Tambahkan widget untuk menampilkan data total transaksi
                                // dari halaman lain
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                    // Tambahkan widget lain sesuai kebutuhan
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
