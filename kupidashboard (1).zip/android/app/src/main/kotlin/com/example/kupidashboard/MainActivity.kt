package com.example.kupidashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
